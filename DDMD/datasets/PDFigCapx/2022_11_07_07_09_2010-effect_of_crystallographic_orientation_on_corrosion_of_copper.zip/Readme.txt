This folder contains the extraction result obtained by using the PDFigCapX system.

The “*.png” files are the figures extracted from the original PDF file.
The “*.txt” files are the captions extracted from the original PDF file.
The “.json” file contains the position information of extracted figures and captions. 
